/**
 * ����һ��������user��ص�ҵ���߼�
 */
package com.dqd.model;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class UserBeanBO {
	private ResultSet rs =null;
	private Connection conn= null;
	private PreparedStatement pstmt = null;
	public UserBean getUB(String u){
		UserBean ub = new UserBean();
		try{
			conn = new ConnDB().getConn();
			pstmt = conn.prepareStatement("select * from guser where uname=? limit 0,1");
			pstmt.setString(1, u);
			rs = pstmt.executeQuery();
			if(rs.next()){
				ub.setAddress(rs.getString(7));
				ub.setEmail(rs.getString(5));
				ub.setGrade(rs.getString(9));
				ub.setPasswd(rs.getString(4));
				ub.setPhone(rs.getString(6));
				ub.setPostcode(rs.getString(8));
				ub.setTruename(rs.getString(3));
				ub.setUid(rs.getInt(1));
				ub.setUname(rs.getString(2));

			}
		}catch(Exception e){
			e.printStackTrace();
		}finally{
			try{
				if(rs!=null){
					rs.close();rs = null;
				}if(pstmt!=null){
					pstmt.close();pstmt = null;
				}if(conn!=null){
					conn.close();conn = null;
				}
			}catch(SQLException e){
				e.printStackTrace();
			}
		}
		return ub;
	}
	public boolean checkUser(String u,String p){
		boolean flag = false;
		try{
			conn = new ConnDB().getConn();
			pstmt = conn.prepareStatement("select * from guser where uname = ?");
			pstmt.setString(1,u);
			rs = pstmt.executeQuery();
			
			//Statement stmt = conn.createStatement();
			//String sql = "select * from guser where uname = '"+ u +"'";
			//rs = stmt.executeQuery(sql);
			if(rs.next()){
				String passwd = rs.getString(4);
				if(p.equals(passwd)){
					flag = true;
				}
			}
		}catch(Exception e){
			e.printStackTrace();
		}finally{
			try{
				if(rs!=null){
					rs.close();rs = null;
				}if(pstmt!=null){
					pstmt.close();pstmt = null;
				}if(conn!=null){
					conn.close();conn = null;
				}
			}catch(SQLException e){
				e.printStackTrace();
			}
		}
		return flag;
	}
}
