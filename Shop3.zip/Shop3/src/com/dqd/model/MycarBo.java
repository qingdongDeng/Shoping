package com.dqd.model;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;

public class MycarBo {
	private ResultSet rs =null;
	private Connection conn= null;
	private PreparedStatement pstmt = null;
	public float allPrice = 0.0f;
	public float allPrice(){
		return allPrice;
	}
	//���ӻ���
	HashMap<String,String> hm = new HashMap<String,String>();
	public String getGoodsNumById(String goodsId){
		return hm.get(goodsId);
	}
	
	public void addGoods(String goodsId,String goodsNum){
		hm.put(goodsId, goodsNum);
	}
	//ɾ������
	public void deleteGoods(String goodsId){
		hm.remove(goodsId);
	}
	//��ջ���
	public void clearGoods(){
		hm.clear();
	}
	//�޸Ļ�������
	public void updataGoods(String goodsId,String goodsNum){
		hm.put(goodsId, goodsNum);
	}
	//��ʾ���ﳵ
	public ArrayList showMycar(){
		ArrayList<GoodBean> al = new ArrayList<GoodBean>();
		try{
			String str = "select * from goods where goodsId in";
			Iterator it = hm.keySet().iterator();
			if(it.hasNext()==true){
				String tmp = "(";
				while(it.hasNext()){
					String goodsId = (String) it.next();
					if(it.hasNext())
						tmp += goodsId+",";
					else
						tmp += goodsId;
				}
				str += (tmp+")");
				conn = new ConnDB().getConn();
				pstmt = conn.prepareStatement(str);
				rs = pstmt.executeQuery();
				if(rs!=null){
					allPrice = 0.0f;
					while(rs.next()){
						GoodBean gb = new GoodBean();
						int goodsId = rs.getInt(1);
						gb.setGoodsId(goodsId);
						
						gb.setGoodsInfo(rs.getString(3));
						gb.setGoodsName(rs.getString(2));
						gb.setGoodsNum(rs.getInt(5));
						float unit = rs.getFloat(4);
						gb.setGoodsPrice(unit);
						allPrice += (unit* Integer.parseInt(this.getGoodsNumById(goodsId+"")));
						gb.setGoodsType(rs.getString(8));
						gb.setPublisher(rs.getString(6));
						gb.setPhoto(rs.getString(7));
						al.add(gb);
					}
				}
			}
		}catch(SQLException e){
			e.printStackTrace();
		}finally{
			try{
				if(rs!=null){
					rs.close();rs = null;
				}if(pstmt!=null){
					pstmt.close();pstmt = null;
				}if(conn!=null){
					conn.close();conn = null;
				}
			}catch(SQLException e){
				e.printStackTrace();
			}
		}
		return al;
	}
}