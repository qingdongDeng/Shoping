package com.dqd.model;

import javax.swing.JFrame;

public class chuangti extends JFrame{
	
}
