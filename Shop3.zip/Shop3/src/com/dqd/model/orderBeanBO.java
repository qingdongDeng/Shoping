package com.dqd.model;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

//�Թ��ﳵ�����ű����д���
public class orderBeanBO {
	/**
	 * ���Ӷ���
	 * @param mcb �û��Ĺ��ﳵ
	 * @param userId �û�id
	 * @return �Ƿ����ӳɹ�
	 */
	private ResultSet rs =null;
	private Connection conn= null;
	private PreparedStatement pstmt = null;
	public boolean addOrder(MycarBo mcb,String userId){
		System.out.print(userId+"ererererer");
		boolean flag = false;
		try{
			conn = new ConnDB().getConn();
			Statement stmt = conn.createStatement();
			
			pstmt = conn.prepareStatement("insert into orderlist(userId,isPayed,totalPrice) values(?,?,?)");
			
			pstmt.setString(1,userId);
			pstmt.setBoolean(2, (boolean)false);
			pstmt.setFloat(3, mcb.allPrice());
			int tmp = pstmt.executeUpdate();
			/*if(tmp==1){
				//����orderDetial��
				//�ӹ��ﳵ��ȡ����Ʒ
				//ȡ���ոմ��ȥ�Ļ��ﶩ�����
				pstmt = conn.prepareStatement("select max(orderId) from orderlist");
				rs = pstmt.executeQuery();
				int orderId = 0;
				if(rs.next()){
					orderId = rs.getInt(1);
				}
				ArrayList al = mcb.showMycar();
				 stmt = conn.createStatement();
				for(int i = 0;i< al.size();++ i){//ѭ���������ݿ�����Ч�ʵ��£�����ʹ�������Ĵ���
					GoodBean gb = (GoodBean)al.get(i);
					stmt.addBatch("insert into orderdetial values('"+orderId+"','"+gb.getGoodsId()+"','"+mcb.getGoodsNumById(gb.getGoodsId()+"")+"')");
				}
				stmt.executeBatch();
				flag = true;
			}else{
				flag = false;
			}*/
		}catch(Exception e){
			e.printStackTrace();
		}finally{
			try{
				if(rs!=null){
					rs.close();rs = null;
				}if(pstmt!=null){
					pstmt.close();pstmt = null;
				}if(conn!=null){
					conn.close();conn = null;
				}
			}catch(SQLException e){
				e.printStackTrace();
			}
		}
		return flag;
	}
}