package com.dqd.model;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

public class GoodsBeanBO {
	private ResultSet rs =null;
	private Connection conn= null;
	private PreparedStatement pstmt = null;
	
	public int getPageCount(int pSize){
		int rowCount = 0;
		int pCount = 0; 
		try{
			conn = new ConnDB().getConn();
			pstmt = conn.prepareStatement("select count(*) from goods");
			rs = pstmt.executeQuery();
			if(rs.next()){
				rowCount = rs.getInt(1);
			}
			if(rowCount % pSize ==0){
				pCount = rowCount / pSize;
			}else{
				pCount = rowCount / pSize + 1;
			}
		}catch(Exception e){
			e.printStackTrace();
		}
		return pCount;
	}
	
	public ArrayList getGoospage(int pSize,int pNow){
		ArrayList al = new ArrayList();
		try{
			conn = new ConnDB().getConn();
			pstmt= conn.prepareStatement("select * from goods order by "
					+ "goodsId asc limit "+(pNow-1)*pSize+","+pSize);
			rs = pstmt.executeQuery();
			while(rs.next()){
				GoodBean gb = new GoodBean();
				gb.setGoodsId(rs.getInt(1));
				gb.setGoodsInfo(rs.getString(3));
				gb.setGoodsName(rs.getString(2));
				gb.setGoodsNum(rs.getInt(5));
				gb.setGoodsPrice(rs.getFloat(4));
				gb.setGoodsType(rs.getString(8));
				gb.setPublisher(rs.getString(6));
				gb.setPhoto(rs.getString(7));
				al.add(gb);
			}
		}catch(Exception e){
			e.printStackTrace();
		}
		
		return al;
	}
	
	public GoodBean getGoodsBean(String id){
		GoodBean gb = new GoodBean();
		try{
			conn = new ConnDB().getConn();
			pstmt = conn.prepareStatement("select * from goods where goodsId =?");
			pstmt.setString(1, id);
			rs = pstmt.executeQuery();
			if(rs.next()){
				gb.setGoodsId(rs.getInt(1));
				gb.setGoodsInfo(rs.getString(3));
				gb.setGoodsName(rs.getString(2));
				gb.setGoodsNum(rs.getInt(5));
				gb.setGoodsPrice(rs.getFloat(4));
				gb.setGoodsType(rs.getString(8));
				gb.setPublisher(rs.getString(6));
				gb.setPhoto(rs.getString(7));
			}
		}catch(Exception e){
			e.printStackTrace();
		}finally{
			try{
				if(rs!=null){
					rs.close();rs = null;
				}if(pstmt!=null){
					pstmt.close();pstmt = null;
				}if(conn!=null){
					conn.close();conn = null;
				}
			}catch(SQLException e){
				e.printStackTrace();
			}
		}
		return gb;
	}
}
