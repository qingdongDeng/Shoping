package com.dqd.model;

public class orderDetialBean {
	private int orderDetialId;
	private int goodsIds;
	public int getOrderDetialId() {
		return orderDetialId;
	}
	public void setOrderDetialId(int orderDetialId) {
		this.orderDetialId = orderDetialId;
	}
	public int getGoodsIds() {
		return goodsIds;
	}
	public void setGoodsIds(int goodsIds) {
		this.goodsIds = goodsIds;
	}
}
