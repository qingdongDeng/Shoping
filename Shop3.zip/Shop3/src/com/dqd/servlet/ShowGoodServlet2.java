package com.dqd.servlet;
import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.dqd.model.UserBean;

public class ShowGoodServlet2 extends HttpServlet {

	public ShowGoodServlet2() {
		super();
	}

	public void destroy() {
		super.destroy(); 
	}
	
	public void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
			response.setContentType("text/html");
			request.setCharacterEncoding("utf-8");
			//������������ڼ���û��Ƿ��½��
			
			UserBean ub = (UserBean) request.getSession().getAttribute("userInfo");
			if(ub == null){
				request.getRequestDispatcher("Shoping2.jsp").forward(request, response);
				
			}else{
				request.getRequestDispatcher("Shoping3.jsp").forward(request, response);
			}
	}

	public void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
			this.doGet(request, response);
	}
	public void init() throws ServletException {
	}

}
