package com.dqd.servlet;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.dqd.model.MycarBo;
import com.dqd.model.UserBean;
import com.dqd.model.orderBeanBO;

@WebServlet("/OrderSolveServlet")
public class OrderSolveServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
   
    public OrderSolveServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.setContentType("text/html");
		response.setCharacterEncoding("UTF-8");
		PrintWriter out = response.getWriter();
		orderBeanBO obb = new orderBeanBO();
		//�õ����ﳵ
		MycarBo mcb = (MycarBo) request.getSession().getAttribute("mycar");
		//�û�id
		UserBean tmp = (UserBean)(request.getSession().getAttribute("userInfo"));
		int userId = tmp.getUid();
		if(obb.addOrder(mcb, ""+userId)){
			//�ɹ�����
			request.getRequestDispatcher("Shoping4.jsp").forward(request, response);
		}else{
			request.getRequestDispatcher("Shoping3.jsp").forward(request, response);
		}
	}
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		this.doGet(request, response);
	}
}
