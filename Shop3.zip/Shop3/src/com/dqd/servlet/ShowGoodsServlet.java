package com.dqd.servlet;
import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.dqd.model.GoodBean;
import com.dqd.model.GoodsBeanBO;

@WebServlet("/ShowGoodsServlet")
public class ShowGoodsServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
    
    public ShowGoodsServlet() {
        super();
    }
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html");
		String type = request.getParameter("type");
		request.setCharacterEncoding("UTF-8");
		response.setContentType("text/html;charset=UTF-8");
		if( (type!=null)&&type.equals("ShowDetial")){
			String goodsId = request.getParameter("id");
			GoodsBeanBO gbb = new GoodsBeanBO();
			GoodBean gb = gbb.getGoodsBean(goodsId);
			request.setAttribute("goodsInfo",gb);
			request.getRequestDispatcher("showDetial.jsp").forward(request, response);
		}else if((type!=null)&&type.equals("fenye")){
			try{
				String pN = request.getParameter("pNow");
				int tmp = Integer.parseInt(pN);
				request.setAttribute("pNow",tmp+"");
				request.getRequestDispatcher("Shopindex.jsp").forward(request, response);
			}catch(NumberFormatException e){
				e.printStackTrace();
			}
		}
	}
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		this.doGet(request, response);
	}

}
