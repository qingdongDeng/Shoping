package com.dqd.servlet;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.dqd.model.GoodBean;
import com.dqd.model.MycarBo;

public class CarSolve extends HttpServlet {
	public CarSolve() {
		super();
	}
	public void destroy() {
		super.destroy(); 
	}
	public void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
			response.setContentType("text/html");
			response.setCharacterEncoding("UTF-8");
			request.setCharacterEncoding("UTF-8");
			PrintWriter out = response.getWriter();
			
			String goodsId = request.getParameter("goodsId");
			String type = request.getParameter("type");
			MycarBo mcb =(MycarBo) request.getSession().getAttribute("mycar");
			if(mcb == null){
				//����һ�����ﳵ
				mcb = new MycarBo();
				request.getSession().setAttribute("mycar", mcb);
			}
			ArrayList<GoodBean> al = new ArrayList<GoodBean>();
			if(type.equals("add")&&(type!=null) ){
				mcb.addGoods(goodsId, "1");
			}else if(type.equals("delete")&&(type!=null)){
				mcb.deleteGoods(goodsId);
			}else if(type.equals("show")&&(type!=null)){
				//do nothing
			}else if(type.equals("deleteAll")&&(type!=null)){
				mcb.clearGoods();
				
			}else if(type.equals("changeNum")&&(type!=null)){
				String goodsIdArray[] = request.getParameterValues("goodsId");
				String cNum[] = request.getParameterValues("cNum");
				if(goodsIdArray!=null){
					for(int i = 0;i < goodsIdArray.length;++ i){
						mcb.updataGoods(goodsIdArray[i],cNum[i]);
					}
				}
			}
			al = mcb.showMycar();
			request.setAttribute("carInfo", al);
			request.getRequestDispatcher("ShowMycar.jsp").forward(request, response);
	}
	public void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
			this.doGet(request, response);
	}
	public void init() throws ServletException {
		// Put your code here
	}
}