var curIndex = 0;
var timeInterval = 2500;
var arr = new Array();
arr[0] = "image/01.jpg";
arr[1] = "image/02.jpg";
arr[2] = "image/03.jpg";
arr[3] = "image/04.jpg";
this.setInterval(Source,timeInterval);
function Source(){
	var tmp = document.getElementById("obj");
	if(curIndex == arr.length-1){
		curIndex = 0;
	}else{
		curIndex += 1;
	}
	tmp.src = arr[curIndex];
}